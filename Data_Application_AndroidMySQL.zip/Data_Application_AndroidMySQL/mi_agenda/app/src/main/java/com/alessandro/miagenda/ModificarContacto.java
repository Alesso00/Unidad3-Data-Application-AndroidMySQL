package com.alessandro.miagenda;


import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.alessandro.miagenda.clases.Configuraciones;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ModificarContacto extends AppCompatActivity {

   // ConexionSQLite objConexion;
    //final String NOMBRE_BASE_DATOS = "miagenda";
    EditText nombre, telefono, correo;

    String id_contacto, nombre_contacto, telefono_contacto, correo_contacto;
    Button botonAgregar, botonRegresar, botonEliminar, botonLlamar, botonenviarcorreo;
   // int id_contacto;
   Configuraciones objConfiguracion = new Configuraciones();
    String URL = objConfiguracion.urlWebServices;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_contacto);

       // objConexion = new ConexionSQLite(ModificarContacto.this, NOMBRE_BASE_DATOS,null,1);
        nombre = findViewById(R.id.txtNombreCompletoEditar);
        telefono = findViewById(R.id.txtTelefonoEditar);
        correo=findViewById(R.id.txtcorreoeditar);
        botonAgregar = findViewById(R.id.btnGuardarContactoEditar);
        botonRegresar = findViewById(R.id.btnRegresarEditar);
        botonEliminar = findViewById(R.id.btnEliminarEditar);
        //boton llamar
        botonLlamar =findViewById(R.id.btnllamar);
        botonenviarcorreo = findViewById(R.id.btnenviarcorreo);

        botonAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                modificar();
            }
        });

        botonRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                regresar();
            }
        });

        botonEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                eliminar();
            }
        });
botonenviarcorreo.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {

        // Crear un Intent para abrir la aplicación de correo
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:"));  // Solo apps de correo electrónico deben responder

        // Agregar la dirección de correo del destinatario
        intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"correo@example.com"});

        // Agregar el asunto del correo
        intent.putExtra(Intent.EXTRA_SUBJECT, "Asunto del correo");

        // Iniciar la actividad para enviar correo
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            // Manejar caso en el que no hay aplicación de correo disponible
             Toast.makeText(ModificarContacto.this, "No se encontró una aplicación de correo disponible.", Toast.LENGTH_LONG).show();
        }
    }

});
        botonLlamar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                llamar();
            }

            private void llamar() {
//Agregue un botón en la pantalla de “Modificar Contacto” que diga “Llamar”
// y al momento de dar clic sobre dicho botón que la aplicación realice la llamada.

                // Obtener el número de teléfono del contacto
                String numeroTelefono = telefono.getText().toString().trim();

                // Comprobar si el número de teléfono no está vacío
                if (!numeroTelefono.isEmpty()) {
                    // Crear un intent para realizar la llamada telefónica
                    Intent intentLlamada = new Intent(Intent.ACTION_DIAL);
                    intentLlamada.setData(Uri.parse("tel:" + numeroTelefono));

                    // Verificar si existe una actividad que pueda manejar el intent de la llamada
                    if (intentLlamada.resolveActivity(getPackageManager()) != null) {
                        // Iniciar la actividad de la llamada
                        startActivity(intentLlamada);
                    } else {
                        // Si no hay una aplicación para realizar llamadas, mostrar un mensaje al usuario
                       Toast.makeText(ModificarContacto.this, "No se puede realizar la llamada. No hay una aplicación disponible. ", Toast.LENGTH_LONG).show();
                    }
                } else {
                    // Si el número de teléfono está vacío, mostrar un mensaje al usuario
                 Toast.makeText(ModificarContacto.this, "El número de teléfono está vacío.", Toast.LENGTH_LONG).show();
                }

            }
        });
    }



    private void modificar() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirmación");
        builder.setMessage("¿Está seguro de que desea Modificar este contacto?");
        builder.setPositiveButton("Sí", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                try {
                    RequestQueue objetoPeticion = Volley.newRequestQueue(ModificarContacto.this);
                    StringRequest peticion = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                JSONObject objJSONResultado = new JSONObject(response);
                                String estado = objJSONResultado.getString("estado");
                                if (estado.equals("1")) {
                                    Toast.makeText(ModificarContacto.this, "Contacto Modificado con éxito", Toast.LENGTH_SHORT).show();
                                    //regresando a pantalla principal
                                    Intent actividad = new Intent(ModificarContacto.this, MainActivity.class);
                                    startActivity(actividad);
                                    ModificarContacto.this.finish();
                                    //finaliza regresar
                                } else {
                                    Toast.makeText(ModificarContacto.this, "Error: " + estado, Toast.LENGTH_SHORT).show();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(ModificarContacto.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }) {
                        @Override
                        protected Map<String, String> getParams() throws AuthFailureError {
                            Map<String, String> params = new HashMap<>();
                            params.put("accion", "modificar");
                            params.put("id_contacto", id_contacto);
                            params.put("nombre", nombre.getText().toString());
                            params.put("telefono", telefono.getText().toString());
                            params.put("correo", correo.getText().toString());
                            return params;
                        }
                    };
                    objetoPeticion.add(peticion);
                } catch (Exception error) {
                    Toast.makeText(ModificarContacto.this, "Error en tiempo de ejecución: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("No", null); // No se realiza ninguna acción si se selecciona "No"
        builder.show();
    }

    private void regresar(){
        Intent actividad = new Intent(ModificarContacto.this, MainActivity.class);
        startActivity(actividad);
        ModificarContacto.this.finish();
    }

    private void eliminar() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirmación");
        builder.setMessage("¿Está seguro de que desea eliminar este contacto?");
        builder.setPositiveButton("Sí", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                try {
                    RequestQueue objetoPeticion = Volley.newRequestQueue(ModificarContacto.this);
                    StringRequest peticion = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                JSONObject objJSONResultado = new JSONObject(response);
                                String estado = objJSONResultado.getString("estado");
                                if (estado.equals("1")) {
                                    Toast.makeText(ModificarContacto.this, "Contacto Eliminado con éxito", Toast.LENGTH_SHORT).show();
                                    Intent actividad = new Intent(ModificarContacto.this, MainActivity.class);
                                    startActivity(actividad);
                                    ModificarContacto.this.finish();

                                } else {
                                    Toast.makeText(ModificarContacto.this, "Error: " + estado, Toast.LENGTH_SHORT).show();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(ModificarContacto.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }) {
                        @Override
                        protected Map<String, String> getParams() throws AuthFailureError {
                            Map<String, String> params = new HashMap<>();
                            params.put("accion", "eliminar");
                            params.put("id_contacto", id_contacto);
                            return params;
                        }
                    };

                    objetoPeticion.add(peticion);
                } catch (Exception error) {
                    Toast.makeText(ModificarContacto.this, "Error en tiempo de ejecución: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setNegativeButton("No", null); // No se realiza ninguna acción si se selecciona "No"
        builder.show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Bundle valoresAdicionales = getIntent().getExtras();
        if (valoresAdicionales == null) {
            Toast.makeText(ModificarContacto.this, "Debe enviar un ID de contacto", Toast.LENGTH_SHORT).show();
            id_contacto = "";
            regresar();
        } else {
            id_contacto = valoresAdicionales.getString("id_contacto");
            nombre_contacto = valoresAdicionales.getString("nombre");
            telefono_contacto = valoresAdicionales.getString("telefono");
            correo_contacto = valoresAdicionales.getString("correo") ;
            verContacto();
        }
    }

    private void verContacto(){
        nombre.setText(nombre_contacto);
        telefono.setText(telefono_contacto);
        correo.setText(correo_contacto);
    }
}
