package com.alessandro.miagenda.clases;

public class Configuraciones {
    public String urlWebServices;

    public Configuraciones(){
        this.urlWebServices = "https://semana3ugb.000webhostapp.com";
    }
}
