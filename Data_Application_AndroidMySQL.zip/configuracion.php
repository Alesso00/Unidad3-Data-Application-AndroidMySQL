<?php
function conectar(){
    //Credenciales
    $server = "localhost";
    $username = "id21143542_alessandro";
    $password = "Semana3UGB*";
    $bd = "id21143542_miagenda";        
    $idConexion = mysqli_connect($server, $username, $password, $bd);
  
    return $idConexion;
}

function desconectar($idConexion){
    try{
        mysqli_close($idConexion);
        $estado = 1;
    } catch(Exception $e) {
        $estado = 0;
    }
    return $estado;
}

function agregarContacto($nombre, $telefono, $correo){
    $idConexion = conectar();
    $sql = "INSERT INTO contactos (nombre, telefono, correo) VALUES ('$nombre', '$telefono', '$correo')";
    if(mysqli_query($idConexion, $sql)){
        $estado = 1;
    } else {
        $estado = "Error: " . mysqli_error($idConexion);
    }
    desconectar($idConexion);
    return $estado;
}

function listarContacto($filtro){
    $idConexion = conectar();
    $datosFila = array();
    $consulta = "SELECT id_contacto, nombre, telefono, correo FROM contactos
                 WHERE (nombre LIKE '%$filtro%' OR telefono LIKE '%$filtro%' OR correo LIKE '%$filtro%')
                 ORDER BY nombre ASC";
    $query = mysqli_query($idConexion, $consulta);
    $nfilas = mysqli_num_rows($query);
    if($nfilas != 0){
        while($aDatos = mysqli_fetch_array($query)){
            $jsonfila = array();
            $id_contacto = $aDatos["id_contacto"];
            $nombre = $aDatos["nombre"];
            $telefono = $aDatos["telefono"];
            $correo = $aDatos["correo"];
            $jsonfila["id_contacto"] = $id_contacto;
            $jsonfila["nombre"] = $nombre;
            $jsonfila["telefono"] = $telefono;
            $jsonfila["correo"] = $correo;
            $datosFila[] = $jsonfila;
        }
    }
    desconectar($idConexion);
    return array_values($datosFila);
}   

function modificarContacto($id_contacto, $nombre, $telefono, $correo){
    $idConexion = conectar();
    $sql = "UPDATE contactos SET nombre='$nombre', telefono='$telefono', correo='$correo' WHERE id_contacto='$id_contacto'";
    if(mysqli_query($idConexion, $sql)){
        $estado = 1;
    } else {
        $estado = "Error: " . mysqli_error($idConexion);
    }
    desconectar($idConexion);
    return $estado;
}

function eliminarContacto($id_contacto){
    $idConexion = conectar();
    $sql = "DELETE FROM contactos WHERE id_contacto='$id_contacto'";
    if(mysqli_query($idConexion, $sql)){
        $estado = 1;
    } else {
        $estado = "Error: " . mysqli_error($idConexion);
    }
    desconectar($idConexion);
    return $estado;
}
?>

